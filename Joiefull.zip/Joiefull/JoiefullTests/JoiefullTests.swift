//
//  JoiefullTests.swift
//  JoiefullTests
//
//  Created by Elo on 22/05/2025.
//

import Testing
@testable import Joiefull

struct JoiefullTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
