//
//  Picture.swift
//  Joiefull
//
//  Created by Elo on 22/05/2025.
//


import Foundation

struct Picture: Codable {
    let url: String
    let description: String
}
