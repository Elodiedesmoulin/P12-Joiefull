//
//  UserArticleState.swift
//  Joiefull
//
//  Created by Elo on 23/05/2025.
//


import Foundation

struct UserArticleState: Codable {
    var isFavorite: Bool
    var rating: Int
}