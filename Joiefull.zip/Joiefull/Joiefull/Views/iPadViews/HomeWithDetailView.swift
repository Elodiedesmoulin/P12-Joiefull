//
//  HomeWithDetailView.swift
//  Joiefull
//
//  Created by Elo on 27/05/2025.
//


import SwiftUI

struct HomeWithDetailView: View {
    @StateObject private var viewModel = HomeViewModel()
    @State private var selectedArticle: RatedArticle?

    var body: some View {
        Group {
            if let article = selectedArticle {
                HStack(spacing: 0) {
                    HomeGridView(viewModel: viewModel, selectedArticle: $selectedArticle)
                        .frame(width: UIScreen.main.bounds.width * 0.45)

                    Divider()

                    DetailView(ratedArticle: article)
                        .frame(maxWidth: .infinity)
                }
            } else {
                HomeGridView(viewModel: viewModel, selectedArticle: $selectedArticle)
            }
        }
        .onAppear {
            viewModel.loadArticles()
        }
    }
}
