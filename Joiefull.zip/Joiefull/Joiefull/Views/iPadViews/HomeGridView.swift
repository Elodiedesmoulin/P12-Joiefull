//
//  HomeGridView.swift
//  Joiefull
//
//  Created by Elo on 27/05/2025.
//


import SwiftUI


struct HomeGridView: View {
    @ObservedObject var viewModel: HomeViewModel
    @Binding var selectedArticle: RatedArticle?

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 32) {
                ForEach(viewModel.groupedArticles.keys.sorted(), id: \ .self) { category in
                    VStack(alignment: .leading) {
                        Text(viewModel.localizedCategory(category))
                            .font(.title2.bold())
                            .padding(.horizontal)

                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 16), count: 5), spacing: 16) {
                            ForEach(viewModel.groupedArticles[category] ?? []) { ratedArticle in
                                ArticleCardView(ratedArticle: ratedArticle)
                                    .onTapGesture {
                                        selectedArticle = ratedArticle
                                    }
                            }
                        }
                        .padding(.horizontal)
                    }
                }
            }
            .padding(.top)
        }
    }
}
