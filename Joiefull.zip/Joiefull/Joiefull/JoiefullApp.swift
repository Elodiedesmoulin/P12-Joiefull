//
//  JoiefullApp.swift
//  Joiefull
//
//  Created by Elo on 22/05/2025.
//

import SwiftUI

@main
struct JoiefullApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
