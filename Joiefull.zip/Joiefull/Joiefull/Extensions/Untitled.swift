//
//  Untitled.swift
//  Joiefull
//
//  Created by Elo on 27/05/2025.
//

import SwiftUI

extension UIDevice {
    static var isPad: Bool {
        UIDevice.current.userInterfaceIdiom == .pad
    }
}
